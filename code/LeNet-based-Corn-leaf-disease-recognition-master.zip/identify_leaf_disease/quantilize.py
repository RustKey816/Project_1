# -*- coding: utf-8 -*-
"""
Created on Sun May 14 17:07:30 2023

@author: 3rdEYE
"""
import sys  # 用于访问 Python 解释器自身使用和维护的变量，同时模块中还提供了一部分函数，可以与解释器进行比较深度的交互
sys.path.append("C:/Users/3rdEYE/Downloads/LeNet-based-Corn-leaf-disease-recognition-master/identify_leaf_disease/")  # 该属性是一个由字符串组成的列表，其中各个元素表示的是 Python 搜索模块的路径

from evaluator.pyd import *
from optimizer import *
from calibrator import *
from evaluator import *
from keras.preprocessing.image import ImageDataGenerator
from keras.models import Sequential
from keras.layers import Conv2D, MaxPooling2D
from keras.layers import Activation, Dropout, Flatten, Dense, BatchNormalization
from keras import backend as K
import tensorflow as tf
import matplotlib.pyplot as plt
import os
import numpy



#导入数据
# 图像维度
img_width, img_height = 32, 32

train_data_dir = './train'
validation_data_dir = './test'
nb_train_samples = 2700
nb_validation_samples = 700
epochs = 10
batch_size = 32

if K.image_data_format() == 'channels_first':
    input_shape = (3, img_width, img_height)
else:
    input_shape = (img_width, img_height, 3)


# 创建模型


model_path = 'model.onnx'
optimized_model_path = optimize_fp_model(model_path)

import os
from PIL import Image
import numpy as np

# 定义图片目录和尺寸
img_dir = "C:/Users/3rdEYE/Downloads/LeNet-based-Corn-leaf-disease-recognition-master/identify_leaf_disease/train/0"
img_size = (32, 32, 3)

# 获取所有图片文件名
img_files = [f for f in os.listdir(img_dir) if f.endswith('.jpg')]

# 初始化训练集数组
train_set = np.zeros((len(img_files), img_size[0], img_size[1], img_size[2]))

# 遍历所有图片文件，将每张图片转换为数组，并添加到训练集数组中
for i, f in enumerate(img_files):
    img = Image.open(os.path.join(img_dir, f))
    img = img.resize((img_size[1], img_size[0])) # 注意，PIL库中的resize参数顺序是(width, height)
    train_set[i] = np.array(img)/255

# 完成训练集数组的生成
print('训练集数组维度：', train_set.shape)

calib_dataset = train_data_dir[0:2000:40]
