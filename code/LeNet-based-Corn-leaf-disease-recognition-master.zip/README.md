# LeNet-based-leaf-disease-recognition
used to recognize 3 types of disease and health of corn leaves  
limited by the upload size,the upload file '.zip' doesn't contain 'original','resize' mentioned in 'readme.pdf'  
users can follow the Step3 mentioned in 'readme.pdf',run 'train_test.py' directly  
for users who wants to test the data they owned:  
1.creat the folder named 'original',and creat the sub-folder named'0','1','2','3' under'original',save the data you owned in these folders.  
2.creat the folder named 'resize',and creat the sub-folder named'0','1','2','3' under'resize'.  
3.follow readme.pdf.  

用于识别玉米叶片病虫害的三种病害以及健康  
因上传大小限制，上传的文件.zip中不包含readme.pdf中所述的original和resize  
可直接按readme.pdf中的第三步直接开始  
如若用户想测试自带植物数据，需按下述三步进行：  
1、创建名为original的文件夹并在文件夹下创建名为0、1、2、3的子文件夹，并将三种病害图片以及健康图片存入其中。  
2、创建名为resize的文件夹并在文件夹下创建名为0、1、2、3的子文件夹。  
3、按照readme.pdf中步骤操作即可。  
